import React, { useEffect, useState, Component } from "react";
import { Navbar,Container,Nav,Card,Button,Row,Col } from 'react-bootstrap';
import { FaBeer,FaLocationArrow } from 'react-icons/fa';
import { FiActivity,FiHeart} from 'react-icons/fi';
import { FcCalendar} from 'react-icons/fc';
import { IoMdNotificationsOutline} from 'react-icons/io';
import {BiUserCircle,BiRocket,BiMessageAlt } from "react-icons/bi";
import {AiOutlineUsergroupAdd,AiFillGift,AiOutlineHome } from "react-icons/ai";
import { CgProfile,HiOutlineTicket} from 'react-icons/cg';
import { TiTicket} from 'react-icons/ti';
import { BsFilePerson} from 'react-icons/bs';
import { GiBookPile} from 'react-icons/gi';
import logo from './banner.jpg';


function Meet() {
    const [value, onChange] = useState(new Date());
  return (
    <div>
         
         <Nav 
    activeKey="/home"
    style={{ backgroundColor: ' #273238'}}
  >
   
    <Nav.Item>
      <Nav.Link eventKey="link-1"><FaLocationArrow/></Nav.Link>
    </Nav.Item>
    <Nav.Item >
      <Nav.Link eventKey="link-2"><BiMessageAlt/></Nav.Link>
    </Nav.Item>
    <Nav.Item >
      <Nav.Link eventKey="link-2"><IoMdNotificationsOutline/></Nav.Link>
    </Nav.Item>
   
  </Nav>
  <Card style={{ backgroundColor: '#ffffff',borderRadius:"10px",margin:"10px"}}>
  <Card.Body>
    <Card.Title><BiUserCircle size={70} /> Ajay</Card.Title>
    <Card.Subtitle className="mb-2 text-muted">Football</Card.Subtitle>
    <Card.Text>
      10 Going
    </Card.Text>
    <Card.Link href="#">Join Now</Card.Link>
    <Card.Link href="#">sent queries</Card.Link>
  </Card.Body>
</Card>
        
<Card style={{ backgroundColor: '#ffffff',borderRadius:"10px",margin:"10px"}}>
  <Card.Body>
    <Card.Title><BiUserCircle size={70} />hari</Card.Title>
    <Card.Subtitle className="mb-2 text-muted">Football</Card.Subtitle>
    <Card.Text>
    5 Going
    </Card.Text>
    <Card.Link href="#">Join Now</Card.Link>
    <Card.Link href="#">sent queries</Card.Link>
  </Card.Body>
</Card>

<Nav activeKey="/home">
    <Nav.Item>
      <Nav.Link eventKey="link-1"><AiOutlineHome/></Nav.Link>
      Home
    </Nav.Item>
   
    <Nav.Item>
      <Nav.Link eventKey="link-2"><BsFilePerson /></Nav.Link>
      Meet
    </Nav.Item>
    <Nav.Item>
      <Nav.Link eventKey="link-2">< GiBookPile /></Nav.Link>
      Learn
    </Nav.Item>
    <Nav.Item>
      <Nav.Link eventKey="link-2"><TiTicket /></Nav.Link>
      Book
    </Nav.Item>
    <Nav.Item style={{color:'Read'}}>
      <Nav.Link eventKey="link-2"><CgProfile /></Nav.Link>
     Me
    </Nav.Item>
   
  </Nav>
        </div>
  )
}

export default Meet
