import React from 'react'
import './Badminton.css'
import { GrAdd } from 'react-icons/gr';
import { FaBeer, FaLocationArrow} from 'react-icons/fa';
import { MdSort } from 'react-icons/md';
import { IoIosNotificationsOutline, IoIosAdd } from 'react-icons/io';
import { AiOutlineMessage, AiOutlineCalendar, AiOutlineHeart, AiOutlineHome } from 'react-icons/ai';
import { BsChevronDown, BsBookmarkStarFill, BsGift, BsFilePerson, BsFilter } from 'react-icons/bs';
function Badminton() {
    return (
        <div>
            <div className="topnav">
                <div className="navLeft">
                    <FaLocationArrow />
                    <span>kaloor,kochi,kerala</span>
                    <BsChevronDown />
                </div>
                <div className="navrRight">
                    <AiOutlineMessage style={{ padding: "0px", marginRight: '5px' }} />
                    <IoIosNotificationsOutline style={{ padding: "0px", marginLeft: '5px' }} />
                </div>


            </div>
            <div class="pagination">

                <a href="#">Swimming</a>
                <a href="#" class="active">Badminton</a>
                <a href="#">Cricket</a>
            </div>
            <div className='seperate'>
                <div className='create'>
                    <GrAdd style={{ float: 'left', margin: '0' }} />
                    <p>Create Activity</p>

                </div>
                <div className='filter'>
                    
                    <BsFilter style={{ float: 'left',marginRight:'1px'}} />
                    <p>Filter</p>
                  

                </div><div className='sort'>
                <MdSort style={{ float: 'left',marginLeft:'230px',marginTop:'-15px',marginLeft:'50px'}}/>
                    <p>Sort</p>
                    </div>

            </div>
        </div>
    )
}

export default Badminton