import React from 'react'
import { Navbar,Container,Nav,Card,Button,Row,Col } from 'react-bootstrap';
import 'react-autocomplete-input/dist/bundle.css';
import { Form } from 'react-bootstrap';
import learn from './trainer.jpg';
import ask from './community.jpg';
import nurition from './nutri.jpg';
import tips from './tips.jpg';
import fit from './fit.jpg';
import logo from './banner.jpg';
import Gear from './Gear.jpg';
import Class from './Class.jpg';
import Football from './football.jpeg';
import { FaBeer,FaLocationArrow } from 'react-icons/fa';
import './Learn.css';
import {GrGroup} from 'react-icons/gr';
import { AiOutlineMessage,AiOutlineCalendar ,AiOutlineHeart,AiOutlineHome} from 'react-icons/ai';
import { IoIosNotificationsOutline} from 'react-icons/io';
import {BiUserCircle,BiRocket,BiMessageAlt,BiPlusCircle } from "react-icons/bi";
import { BsChevronDown,BsBookmarkStarFill ,BsGift,BsFilePerson } from 'react-icons/bs';
import { GiBookPile} from 'react-icons/gi';

import { CgProfile,HiOutlineTicket} from 'react-icons/cg';
import { TiTicket} from 'react-icons/ti';
function Learn() {
  return (
    <div>   <div className="topnavL">
    <div className="navLeftL">
        <FaLocationArrow />
        <span>kaloor,kochi,kerala</span>
        <BsChevronDown />
    </div>
    <div className="navrRightL">
        <AiOutlineMessage style={{ padding: "0px", marginRight: '5px' }} />
        <IoIosNotificationsOutline style={{ padding: "0px", marginLeft: '5px' }} />
    </div>

</div>
  <Row>
    <Col><Nav.Link href="/home"><img src={learn} class="card-img" alt="..."  />
    Trainer led Sessions
    </Nav.Link></Col>
    <Col ><Nav.Link href="/home"><img src={ask} class="card-img" alt="..."  />Ask the community</Nav.Link></Col>
    
  </Row>
  
  {/* <span>resources</span> */}
  <Row>
    <Col><Nav.Link href="/home"><img src={Football} class="card-img" alt="..."  />
    Game Basics
    </Nav.Link></Col>
    <Col ><Nav.Link href="/home"><img src={tips} class="card-img" alt="..."  />Techniques Tactics</Nav.Link></Col>
    <Col><Nav.Link href="/home"><img src={fit} class="card-img" alt="..."  />Fitness & Injuries</Nav.Link></Col>
  </Row>
  <Row>
    <Col><Nav.Link href="/home"><img src={nurition} class="card-img" alt="..."  />
    Nutrition
    </Nav.Link></Col>
    <Col ><Nav.Link href="/home"><img src={Gear} class="card-img" alt="..."  />Gear</Nav.Link></Col>
    <Col><Nav.Link href="/home"><img src={Class} class="card-img" alt="..."  />Master Classes</Nav.Link></Col>
  </Row>
  <Nav.Link href="/home"><img src={logo} class="card-img" alt="..."  /></Nav.Link>
 


  <div className="bottomNav2">
        <div className="cc2">
                    <AiOutlineHome/>
                    <p>Home</p>
                </div>
                <div className="cc2">
                    <BsFilePerson  />
                    <p>Meet</p>
                </div>
                <div className="cc2">
                    <GiBookPile />
                    <p>Learn</p>
                </div>
                <div className="cc2">
                    <TiTicket  />
                    <p>Book</p>
                </div>
                <div className="cc2">
                    <CgProfile />
                    <p>Me</p>
                </div>
        </div>
 
  </div>
  )
}

export default Learn