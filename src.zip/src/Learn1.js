import React from 'react'
import learn from './trainer.jpg';
import ask from './community.jpg';
import fit from './fit.jpg';
import Gear from './Gear.jpg';
import Class from './Class.jpg';
import nurition from './nutri.jpg';
import { FaBeer, FaLocationArrow } from 'react-icons/fa';
import { AiOutlineMessage, AiOutlineCalendar, AiOutlineHeart, AiOutlineHome } from 'react-icons/ai';
import { BsChevronDown, BsBookmarkStarFill, BsGift, BsFilePerson, BsFilter } from 'react-icons/bs';
import { IoIosNotificationsOutline } from 'react-icons/io';
import tips from './tips.jpg';
import { GiBookPile} from 'react-icons/gi';
import { CgProfile,HiOutlineTicket} from 'react-icons/cg';
import { TiTicket} from 'react-icons/ti';
import './Learn1.css';
import Football from './football.jpeg';

function Learn1() {
    return (
        <div>
            <div className="topnav">
                <div className="navLeft">
                    <FaLocationArrow />
                    <span>kaloor,kochi,kerala</span>
                    <BsChevronDown />
                </div>
                <div className="navrRight">
                    <AiOutlineMessage style={{ padding: "0px", marginRight: '5px' }} />
                    <IoIosNotificationsOutline style={{ padding: "0px", marginLeft: '5px' }} />
                </div>


            </div>
            <div className="sport">
                <p>Running</p>
                <BsFilter style={{ float: 'right', marginRight: '10px' }} />

            </div>
            <div className="trainercommunity">
                <div className="TC">
                    <img src={learn} class="card-img" alt="..." />
                    <div class="centered">Trainer led Sessions</div>

                </div>
                <div className="TC">
                <img src={ask} class="card-img" alt="..."  />
                    <div class="centered">Ask the Community</div>
                </div>
            </div>
            <div className="resourcesTitle">
                <p>Resources</p>
            </div>
            <div className='elementContainer'>
                <div className="elementrow">
                    <div className='element'>
                    <img src={Football} class="card-img" alt="..." />
                    <div class="namming">Game Basics</div>
                   

                    </div>
                    <div className='element'>
                    <img src={tips} class="card-img" alt="..." />
                    <div class="namming">Techiniques & Tatics</div>

                    </div>
                    <div className='element'>
                    <img src={fit} class="card-img" alt="..." />
                    <div class="namming">Fitness & Injuries</div>

                    </div>
                </div>
                <div className="elementrow1">
                    <div className='element'>
                    <img src={nurition} class="card-img" alt="..." />
                    <div class="namming">Nutritions</div>

                    </div>
                    <div className='element'>
                    <img src={Gear}  class="card-img" alt="..." />
                    <div class="namming">Gear</div>

                    </div>
                    <div className='element'>
                    <img src={Class} class="card-img" alt="..." />
                    <div class="namming">Master Class</div>

                    </div>
                </div>


            </div>
            <div className="bottomNav">
        <div className="c2">
                    <AiOutlineHome/>
                    <p>Home</p>
                </div>
                <div className="c2">
                    <BsFilePerson  />
                    <p>Meet</p>
                </div>
                <div className="c2">
                    <GiBookPile />
                    <p>Learn</p>
                </div>
                <div className="c2">
                    <TiTicket  />
                    <p>Book</p>
                </div>
                <div className="c2">
                    <CgProfile />
                    <p>Me</p>
                </div>
        </div>
        </div>
    )
}

export default Learn1