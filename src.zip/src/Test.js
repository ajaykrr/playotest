import React from 'react'
import ask from './community.jpg';
import 'font-awesome/css/font-awesome.min.css';
import { FaLocationArrow } from 'react-icons/fa';
import {GrGroup} from 'react-icons/gr';
import { AiOutlineMessage,AiOutlineCalendar ,AiOutlineHeart,AiOutlineHome} from 'react-icons/ai';
import { IoIosNotificationsOutline} from 'react-icons/io';
import {BiUserCircle,BiRocket,BiMessageAlt,BiPlusCircle } from "react-icons/bi";
import { BsChevronDown,BsBookmarkStarFill ,BsGift,BsFilePerson } from 'react-icons/bs';
import { GiBookPile} from 'react-icons/gi';
import './Test.css';
import Football from './football.jpeg';
import learn from './trainer.jpg';
import { CgProfile,HiOutlineTicket} from 'react-icons/cg';
import { TiTicket} from 'react-icons/ti';
function Test() {
    return (<div>
        <div className="topnav">
            <div className="navLeft">
                <FaLocationArrow />
                <span>kaloor,kochi,kerala</span>
                <BsChevronDown />
            </div>
            <div className="navrRight">
                <AiOutlineMessage style={{ padding: "0px", marginRight: '5px' }} />
                <IoIosNotificationsOutline style={{ padding: "0px", marginLeft: '5px' }} />
            </div>

        </div>
        <div className="Userprofile">
            <div className="pic">
                <BiUserCircle size={65} />

            </div>
            <div className="Info">
                <h6>Hey Ajay</h6>
                <p>Warming Up</p>
               

                <p>0 Activities</p>
                
                <p>0 Playpals</p>

            </div>
        </div>
        <div className="activityBox">
            <div className='activR1'>

                <div className="c1">
                    <AiOutlineCalendar />
                    <p>My Calender</p>
                </div>
                <div className="c1">
                    <BiPlusCircle />
                    <p>Create Activity</p>
                </div>
                <div className="c1">
                    <BiRocket/>
                    <p>Quick Boost</p>
                </div>
                <div className="c1"> 
                <AiOutlineHeart />
                    <p>Favourite Vanue</p></div>

            </div>
            <div className='activR1'>

                <div className="c1">
                    <GrGroup/>
                    <p>Groups</p>
                </div>
                <div className="c1">
                    <BsBookmarkStarFill />
                    <p>Learderboard</p>
                </div>
                <div className="c1">
                    <BsGift />
                    <p>Offers</p>
                </div>
                

            </div>
        </div>
        <div className='banner1'>
            <div className="bannerhalf">
                <h2>MEET</h2>
                <p>With Player Nearby</p>

            </div>
            <div className="bannerhalf">
            <img src={learn} class="card-img" alt="..."  />

           </div>

        </div>
        <div className='banner'>
            <div className="bannerhalf">
                <h2>LEARN</h2>
                <p>From Expert & Community</p>

            </div>
            <div className="bannerhalf">
            <img src={ask} class="card-img" alt="..."  />

           </div>

        </div>
        <div className='banner3'>
            <div className="bannerhalf">
                <h2>BOOK</h2>
                <p>Venue,Event & Gear</p>

            </div>
            <div className="bannerhalf">
            <img src={Football} class="card-img" alt="..."  />

           </div>

        </div>
        
        <div className="bottomNav">
        <div className="c2">
                    <AiOutlineHome/>
                    <p>Home</p>
                </div>
                <div className="c2">
                    <BsFilePerson  />
                    <p>Meet</p>
                </div>
                <div className="c2">
                    <GiBookPile />
                    <p>Learn</p>
                </div>
                <div className="c2">
                    <TiTicket  />
                    <p>Book</p>
                </div>
                <div className="c2">
                    <CgProfile />
                    <p>Me</p>
                </div>
        </div>
    </div>
    )
}

export default Test