
import { Navbar,Container,Nav,Card } from 'react-bootstrap';
import logo from './banner.jpg';
import React, { useEffect, useState, Component } from "react";
import logo2 from './banner2.jpg';
import { FaBeer,FaLocationArrow } from 'react-icons/fa';
import { FiActivity,FiHeart} from 'react-icons/fi';
import { FcCalendar} from 'react-icons/fc';
import { IoMdNotificationsOutline} from 'react-icons/io';
import {BiUserCircle,BiRocket,BiMessageAlt } from "react-icons/bi";
import {AiOutlineUsergroupAdd,AiFillGift,AiOutlineHome } from "react-icons/ai";
import { CgProfile,HiOutlineTicket} from 'react-icons/cg';
import { TiTicket} from 'react-icons/ti';
import { BsFilePerson} from 'react-icons/bs';
import { GiBookPile} from 'react-icons/gi';
import './Home.css';
function Home() {
  return (
    <div>
      <div className="Navbar">
      <Nav 
    activeKey="/home"
   
  >
   
    <Nav.Item>
      <Nav.Link eventKey="link-1"><FaLocationArrow/></Nav.Link>
    </Nav.Item>
    <Nav.Item >
      <Nav.Link eventKey="link-2"><BiMessageAlt/></Nav.Link>
    </Nav.Item>
    <Nav.Item >
      <Nav.Link eventKey="link-2"><IoMdNotificationsOutline/></Nav.Link>
    </Nav.Item>
   
  </Nav>
  </div>
  <div className="card1">
  <Card style={{ backgroundColor: '#ffffff',borderRadius:"10px",margin:"10px"}}>
  <Card.Body>
    <Card.Title><BiUserCircle size={70} />Hey Ajay</Card.Title>
    <Card.Subtitle className="mb-2 text-muted"></Card.Subtitle>
    <Card.Text>
      Warming Up   . 0 Activities . 0 Playpals
    </Card.Text>
    <Card.Link href="#"></Card.Link>
    <Card.Link href="#"></Card.Link>
  </Card.Body>
</Card></div>
<div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src={logo} alt="First slide"/>
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src={logo2} alt="Second slide"/>
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src={logo} alt="Third slide"/>
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
<div className="cardicon">

    <div className="linkitem"><BiUserCircle size={75}style={{  backgroundColor: 'blue',borderRadius:"70px"}} /><div ClassName="cardnav">profile</div></div>
    <div className="linkitem"><FiActivity size={75}style={{  backgroundColor: '#fc0398',borderRadius:"70px"}}  /><div ClassName="cardnav">Activity</div></div>
  
  
    <div className="linkitem"><FcCalendar size={75}style={{  backgroundColor: 'pink',borderRadius:"70px"}} /><div ClassName="cardnav">Calender</div></div>
    {/* <Card.Link href="#"><BiRocket size={75}style={{  backgroundColor: '#03fcc6',borderRadius:"70px"}} /><div ClassName="cardnav">Quick Boost</div></Card.Link>
    <Card.Link href="#"><FiHeart size={75}style={{  backgroundColor: '#31747a',borderRadius:"70px"}} /><div ClassName="cardnav">Favourite</div></Card.Link>
    <Card.Link href="#"><AiOutlineUsergroupAdd size={75}style={{  backgroundColor: '#527a55',borderRadius:"70px"}} /><div ClassName="cardnav">Groups</div></Card.Link>
    <Card.Link href="#"><AiFillGift size={75}style={{  backgroundColor: '#2399ba',borderRadius:"70px"}} /><div ClassName="cardnav">Offers</div></Card.Link> */}
   </div>
<div className="NavLinks">
<Nav.Link href="/home"><img  src={logo} class="card-img" alt="..."  /></Nav.Link>
<Nav.Link href="/home"><img src={logo} class="card-img" alt="..."  /></Nav.Link>
<Nav.Link href="/home"><img src={logo} class="card-img" alt="..."  /></Nav.Link>

</div>
<div className="nav2">
<Nav activeKey="/home">
    <Nav.Item>
      <Nav.Link eventKey="link-1"><AiOutlineHome/></Nav.Link>
      Home
    </Nav.Item>
   
    <Nav.Item>
      <Nav.Link eventKey="link-2"><BsFilePerson /></Nav.Link>
      Meet
    </Nav.Item>
    <Nav.Item>
      <Nav.Link eventKey="link-2">< GiBookPile /></Nav.Link>
      Learn
    </Nav.Item>
    <Nav.Item>
      <Nav.Link eventKey="link-2"><TiTicket /></Nav.Link>
      Book
    </Nav.Item>
    <Nav.Item style={{color:'Read'}}>
      <Nav.Link eventKey="link-2"><CgProfile /></Nav.Link>
     Me
    </Nav.Item>
   
  </Nav>
  </div>

        </div>
  )
  
}

export default Home

